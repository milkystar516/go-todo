import CoreForm from "@rjsf/core"
import RjsfForm from "@rjsf/shadcn"
import type {
  RJSFSchema,
  TemplatesType,
  UiSchema,
} from "@rjsf/utils"
import { forwardRef, useImperativeHandle, useRef } from "react"

import { rjsfValidator } from "../../lib/schema/rjsfValidator"

export interface JsonSchemaFormHandle {
  validateForm: () => boolean
}

interface JsonSchemaFormProps {
  idPrefix: string
  schema: RJSFSchema
  uiSchema?: UiSchema
  formData: Record<string, unknown>
  templates?: Partial<TemplatesType<Record<string, unknown>>>
  readOnly?: boolean
  disabled?: boolean
  onChange: (formData: Record<string, unknown>) => void
}

export const JsonSchemaForm = forwardRef<
  JsonSchemaFormHandle,
  JsonSchemaFormProps
>(function JsonSchemaForm(
  {
    idPrefix,
    schema,
    uiSchema,
    formData,
    templates,
    readOnly = false,
    disabled = false,
    onChange,
  },
  ref,
) {
  const formRef = useRef<CoreForm<Record<string, unknown>>>(null)

  useImperativeHandle(
    ref,
    () => ({
      validateForm: () => formRef.current?.validateForm() ?? false,
    }),
    [],
  )

  return (
    <RjsfForm
      ref={formRef}
      idPrefix={idPrefix}
      tagName="div"
      schema={schema}
      uiSchema={uiSchema}
      formData={formData}
      validator={rjsfValidator}
      templates={templates}
      onChange={({ formData: nextFormData }) =>
        onChange(nextFormData ?? {})
      }
      readonly={readOnly}
      disabled={disabled}
      liveValidate="onBlur"
      omitExtraData
      liveOmit="onChange"
      showErrorList={false}
    >
      <></>
    </RjsfForm>
  )
})