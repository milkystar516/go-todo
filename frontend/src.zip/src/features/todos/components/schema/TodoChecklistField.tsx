import type { FieldProps } from "@rjsf/utils"
import { useTranslation } from "react-i18next"

import { Checkbox } from "#components/ui/checkbox"
import { Field, FieldError } from "#components/ui/field"
import { Input } from "#components/ui/input"
import { cn } from "#lib/utils"

interface ChecklistItem {
  text: string
  completed: boolean
}

function normalizeChecklistItem(value: unknown): ChecklistItem {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return { text: "", completed: false }
  }

  const item = value as Record<string, unknown>

  return {
    text: typeof item.text === "string" ? item.text : "",
    completed: item.completed === true,
  }
}

export function TodoChecklistField({
  formData,
  errorSchema,
  fieldPathId,
  disabled = false,
  readonly = false,
  onChange,
  onBlur,
}: FieldProps) {
  const { t } = useTranslation()
  const item = normalizeChecklistItem(formData)

  const errorMessages = [
    ...(errorSchema?.text?.__errors ?? []),
    ...(errorSchema?.completed?.__errors ?? []),
  ]
  const invalid = errorMessages.length > 0

  function update(patch: Partial<ChecklistItem>) {
    onChange({ ...item, ...patch }, fieldPathId.path)
  }

  return (
    <Field data-invalid={invalid} className="gap-1">
      <div className="flex min-w-0 items-center gap-2">
        <Checkbox
          checked={item.completed}
          disabled={disabled || readonly}
          aria-label={t("todos.form.checklist.completed")}
          onCheckedChange={(checked) => update({ completed: checked === true })}
          onBlur={() => onBlur(`${fieldPathId.$id}_completed`, item.completed)}
        />

        <Input
          value={item.text}
          disabled={disabled}
          readOnly={readonly}
          aria-label={t("todos.form.checklist.item")}
          aria-invalid={invalid || undefined}
          className={cn(
            "h-8 flex-1 rounded-none border-0 bg-transparent px-1 shadow-none",
            "focus-visible:border-transparent focus-visible:ring-0",
            item.completed && "text-muted-foreground line-through",
          )}
          onChange={(event) => update({ text: event.target.value })}
          onBlur={() => onBlur(`${fieldPathId.$id}_text`, item.text)}
        />
      </div>

      {invalid && <FieldError>{errorMessages.join(" ")}</FieldError>}
    </Field>
  )
}